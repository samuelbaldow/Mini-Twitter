document.addEventListener('DOMContentLoaded', () => {
    const postForm = document.getElementById('postForm');
    const postArea = document.getElementById('postArea');

    postForm.addEventListener('submit', function(event) {
        event.preventDefault();

        const postText = document.getElementById('postText').value;
        if (postText.trim() === '') return;

        const postDiv = document.createElement('div');
        postDiv.classList.add('card', 'my-3');
        postDiv.innerHTML = `
            <div class="card-body">
                <p class="card-text">${postText}</p>
                <div>
                    <button class="btn btn-outline-primary btn-sm me-2 like-btn">Curtir</button>
                    <button class="btn btn-outline-danger btn-sm delete-btn">Excluir</button>
                </div>
            </div>
        `;

        postArea.prepend(postDiv);
        postForm.reset();

        const likeBtn = postDiv.querySelector('.like-btn');
        const deleteBtn = postDiv.querySelector('.delete-btn');

        likeBtn.addEventListener('click', function() {
            this.classList.toggle('btn-primary');
            this.classList.toggle('btn-outline-primary');

            if (this.classList.contains('btn-primary')) {
                if (!this.querySelector('.like-emoji')) {
                    const likeEmoji = document.createElement('span');
                    likeEmoji.classList.add('like-emoji');
                    likeEmoji.innerHTML = '❤️'; // Emoji de curtida
                    this.appendChild(likeEmoji);
                }
            } else {
                const likeEmoji = this.querySelector('.like-emoji');
                if (likeEmoji) {
                    likeEmoji.remove();
                }
            }
        });

        deleteBtn.addEventListener('click', function() {
            postDiv.remove();
        });
    });
});
